README:

Open Terminal and cd to this folder, execute "chmod +x RUN_THIS.py" and then execute "./RUN_THIS.py"
