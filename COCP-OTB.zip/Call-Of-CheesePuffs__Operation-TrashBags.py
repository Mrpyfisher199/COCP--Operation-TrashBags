#!/usr/bin/python
#coding: latin-1
import os
try:
	import pygame
except Exception as e:
	print "Sorry, it seems you dont have a library called pygame :(\nWould you like to download it (it will require your password)? (y/n)"
	an = raw_input("> ").upper()
	if an != "N":
		print "Starting"
		os.system("sudo -H easy_install pip")
		os.system("sudo -H pip install pygame")
		try:
			import pygame
			print 'You have successfully installed PYGAME!!!'
		except Exception as e:
			print "Looks like something went wrong :("
			quit()
	else:
		print "Well, thats a shame :("
		quit()
import pygame, math, random
pygame.init()
#Music
pygame.mixer.init()
pygame.mixer.set_num_channels(8)
pygame.mixer.music.load('sound/fish.wav')
play = pygame.mixer.Channel(1)
# welcome to Call-Of-CheesePuffs__Operation-TrashBags
w,h = 750,444
#Screen
gameDisplay = pygame.display.set_mode((w,h))
#Name
pygame.display.set_caption('Call Of CheesePuffs--Operation TrashBags')
#Colors
white = (255,255,255)
black = (0,0,0)
red = (255,0,0)
green = (0,155,0)
silver=(179, 179, 179)
#Logo
icon = pygame.image.load('img/icon.png')
pygame.display.set_icon(icon)
#Sloth list
sloth_list = pygame.sprite.Group()
#Clock (Speed of game)
clock = pygame.time.Clock()
fps=15
dt=clock.tick(fps)
#Entity imgs
playImg = pygame.image.load('img/play.png')
playImg1 = pygame.image.load('img/play1.png')
background = pygame.image.load('img/background.png')
cheesepuffs = pygame.image.load('img/CHEESEPUFFS.png')
#Fonts
smallfont = pygame.font.Font("Fontspy/c.ttf", 25)
medfont = pygame.font.Font("Fontspy/b.ttf", 50)
med1font = pygame.font.Font("Fontspy/b.ttf", 38)
largefont = pygame.font.Font("Fontspy/b.ttf", 80)
#SLOTH (The deadly sin)
class SLOTH(pygame.sprite.Sprite):
	def __init__(self, h):
		pygame.sprite.Sprite.__init__(self)
		self.image = pygame.image.load('img/rat1.png').convert_alpha()
		self.rect = self.image.get_rect()
		self.x1 = 0
		self.h = h
		self.rect.y = h
	def update(self):
		self.rect.x+=2
		aaa=self.rect.x
		if self.x1 == 0:
			self.x1=1
			self.image = pygame.image.load('img/rat.png').convert_alpha()
			self.rect = self.image.get_rect()
			self.rect.y = self.h
			self.rect.x = aaa
		else:
			self.x1=0
			self.image = pygame.image.load('img/rat1.png').convert_alpha()
			self.rect = self.image.get_rect()
			self.rect.y = self.h
			self.rect.x = aaa
	def kill(self):
		sloth_list.remove(self)
#TrashBag Cod3
class Cod3(pygame.sprite.Sprite):
    def __init__(self, mouse, s):
    	pygame.sprite.Sprite.__init__(self)
    	self.TrashBag = pygame.image.load('img/Trash.png').convert_alpha()
        self.mouse_x, self.mouse_y = mouse[0], mouse[1]
        self.player = s
        self.x1 = s[0]-22.5
        self.y1 = s[1]-22.5
        self.x = s[0]
        self.y = s[1]
        self.rot = 0
        self.rect = self.TrashBag.get_rect()
        self.rect.x = s[0]-22.5
        self.rect.y = s[1]-22.5
        self.score = 0
    def update(self):
    	self.score = 0
    	trashBag = pygame.image.load('img/Trash.png')
        speed = 25.0
        ranges = 200
        distance = [self.mouse_x - self.player[0], self.mouse_y - self.player[1]]
        norm = math.sqrt(distance[0] ** 2 + distance[1] ** 2)
        direction = [distance[0] / norm, distance[1 ] / norm]
        bullet_vector = [direction[0] * speed, direction[1] * speed]
        self.x += bullet_vector[0]
        self.y += bullet_vector[1]
        self.x1,self.y1=self.x-22.5,self.y-22.5
        trashBag = pygame.transform.rotate(trashBag, self.rot)
        self.rot+=100
        self.rect.x = self.x1
        self.rect.y = self.y1
        for i in sloth_list:
        	if pygame.sprite.collide_rect(self, i):
        		i.kill()
        		self.score+=1
        gameDisplay.blit(trashBag, (self.x1, self.y1))
        if self.mouse_x > self.x:
        	return [False,self.score]
        else:
        	return [True,self.score]

#Font Manager
def text_objects(text,color,size):
    if size == "small":
        textSurface = smallfont.render(text, True, color)
    elif size == "medium":
        textSurface = medfont.render(text, True, color)
    elif size == "med":
        textSurface = med1font.render(text, True, color)
    elif size == "large":
        textSurface = largefont.render(text, True, color)   
    return textSurface, textSurface.get_rect()
#Message Renderer
def message_to_screen(msg,color,a, y_displace, size):
    textSurf, textRect = text_objects(msg,color, size)
    textRect.center = (a[0]), (a[1])+y_displace
    gameDisplay.blit(textSurf, textRect)
#Game Intro
def gameIntro():
	while 1:
		mouse=pygame.mouse.get_pos()
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				quit()
			if event.type == pygame.MOUSEBUTTONUP:
				if w/5-20-1 < mouse[0] < w/5-20+500+1 and h/2-1 < mouse[1] < h/2+142:
					gameLoop()
		gameDisplay.fill(white)
		gameDisplay.blit(background, (0,0))
		gameDisplay.blit(cheesepuffs, (w-180,0))
		message_to_screen("Call Of CheesePuffs", red, [w/2,h/3-50],0, "med")
		message_to_screen("Operation TrashBags", red, [w/2,h/3],0, "med")
		playimg = playImg
		if w/5-20-1 < mouse[0] < w/5-20+500+1 and h/2-1 < mouse[1] < h/2+142:
			playimg = playImg1
		gameDisplay.blit(playimg, [w/5-20, h/2])
		pygame.display.update()
#Game Over
def gameOver():
	for i in range(100):
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				quit()
		gameDisplay.fill(white)
		gameDisplay.blit(background, (0,0))
		gameDisplay.blit(cheesepuffs, (w-180,0))
		message_to_screen("GAME OVER", red, [w/2, h/2],0,"large")
		pygame.display.update()
	gameIntro()
#Game Loop
def gameLoop():
	fish1 = pygame.image.load('img/fish1.png')
	fish2 = pygame.image.load('img/fish12.png')
	gameExit = False
	cols={1 : [],2 : [], 3 : [], 4 : [], 5 : []}
	lth=5
	pts=0
	tk = 0
	x1=h-h/30-70
	x2=30
	file1 = open('music.txt', 'r')
	music = file1.read().strip('\n')
	if music == 'True':
		music = True
	else:
		music = False
	pause = False
	s = [w-50, h-h/3-70+40]
	target = None
	speed = 10
	throw=False
	fish=0
	maxSloth = 3
	mxltsc = 0
	fish10 = 0
	fish11 = False
	fish111 = False
	fish110=False
	while not gameExit:
		if music:
			if not pygame.mixer.music.get_busy():
				pygame.mixer.music.play()
		mouse=pygame.mouse.get_pos()
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				quit()
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_ESCAPE:
					gameExit = True
					for i in sloth_list:
						sloth_list.remove(i)
				elif event.key == pygame.K_RETURN:
					if pause == True:
						pause = False
					else:
						pause = True
			elif event.type == pygame.MOUSEBUTTONUP:
				if w-180+45 < mouse[0] < w-180+45+20 and 100 < mouse[1] < 120:
					if music == False:
						music = True
						file = open('music.txt', 'w')
						file.write("True\n")
						file.close()
						file1 = open('music.txt', 'r')
						music = True
					else:
						music = False
						pygame.mixer.music.stop()
						file = open('music.txt', 'w')
						file.write("False\n")
						file.close()
						file1 = open('music.txt', 'r')
						music = False
				elif mouse[0] < w-180 and pause == False and throw == False:
					target=mouse
					throw=True
					fish110 = True
					fish11 = True
					fish10 = 0
		gameDisplay.fill(white)
		gameDisplay.blit(background, (0,0))
		gameDisplay.blit(cheesepuffs, (w-180,0))
		#Entity's
		if tk == 20:
			fish2 = pygame.image.load('img/fish22.png')
			fish1 = pygame.image.load('img/fish22.png')
		elif tk == 30:
			fish2 = pygame.image.load('img/fish12.png')
			fish1 = pygame.image.load('img/fish1.png')
			tk=0
		gameDisplay.blit(fish1, (w-180+50,h-h/3-70+40-fish10))
		gameDisplay.blit(fish2, (w-180+45,20))
		if pause == False:
			if fish110 == True:
				if fish111 == True:
					fish10-=15
				else:
					fish10+=15
				if fish10 > 30:
					fish11 = False
					fish111 = True
				elif fish10 == 0:
					fish111 = False
					fish110 = False
			if throw == True:
				if fish == 0:
					fish+=1
					trashbag1 = Cod3(target,s)
				throw,score = trashbag1.update()
				pts+=score
				if throw == False:
					fish = 0
			mxltsc+=1
			if mxltsc > 50:
				maxSloth += 2
				mxltsc = 0
			while len(sloth_list) < maxSloth:
				ala = random.randrange(h)
				while ala > h-35 or ala < 35:
					ala = random.randrange(h)
				sloth = SLOTH(ala)
				sloth_list.add(sloth)
			for i in sloth_list:
				if i.rect.x > w-180-40:
					for i in sloth_list:
						sloth_list.remove(i)
					pygame.mixer.music.stop()
					gameOver()
			sloth_list.update()
			sloth_list.draw(gameDisplay)
		else:
			message_to_screen('Paused', red, ((w-180)/2, h/2-10), 0, "large")
			sloth_list.draw(gameDisplay)
		#Right side stuff...
		pygame.draw.rect(gameDisplay, silver, (w-180, h-h/3,180, lth))
		pygame.draw.rect(gameDisplay, silver, (w-180+180/4, h-h/3,lth, 40))
		pygame.draw.rect(gameDisplay, silver, (w-180+180/4*2, h-h/3,lth, 40))
		pygame.draw.rect(gameDisplay, silver, (w-180+180/4*3, h-h/3,lth, 40))
		#Settings
		pygame.draw.rect(gameDisplay, black, (w-180+45, 100, 20, 20))
		
		if music == True:
			pygame.draw.rect(gameDisplay, red, (w-180+50, 105, 10, 10))
		else:
			pygame.draw.rect(gameDisplay, white, (w-180+50, 105, 10, 10))
		message_to_screen('Music', black, (w-180+105, 110), 0, "small")
		#Other Right Side Stuff :P
		pygame.draw.rect(gameDisplay, black, (w-180, 0,lth, h))
		pygame.draw.rect(gameDisplay, black, (w-180, h/3,180, lth))
		pygame.draw.rect(gameDisplay, black, (w-180, h-h/3+40,180, lth))
		message_to_screen('Pts: '+str(pts), red, (w-90, h-h/3+100), 0, "small")
		#Borders
		pygame.draw.rect(gameDisplay, black, (0, 0,lth, h))
		pygame.draw.rect(gameDisplay, black, (0, 0,w, lth))
		pygame.draw.rect(gameDisplay, black, (0, h-lth,w, lth))
		pygame.display.update()
		clock.tick(fps)
		tk+=1
	pygame.mixer.music.stop()
	return
gameIntro()
gameLoop()

	

